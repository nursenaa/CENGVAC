package ceng.ceng351.cengvacdb;

import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CENGVACDB implements ICENGVACDB {
    private Connection connection;

    @Override
    public void initialize() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://144.122.71.121:8080/db2310498?useSSL=false", "e2310498", "$c#w?!25yOv-");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int createTables() {
        int counter = 0;
        String UserTable = "CREATE TABLE User(" +
                "userID int NOT NULL," +
                "userName varchar(30)," +
                "age int," +
                "address varchar(150)," +
                "password varchar(30)," +
                "status varchar(15)," +
                "PRIMARY KEY (userID)" +
                ")";
        String VaccineTable = "CREATE TABLE Vaccine(" +
                "code int NOT NULL," +
                "vaccinename varchar(30)," +
                "type varchar(30)," +
                "PRIMARY KEY (code)" +
                ")";
        String VaccinationTable = "CREATE TABLE Vaccination(" +
                "code int," +
                "userID int," +
                "dose int," +
                "vacdate date," +
                "FOREIGN KEY (userID) REFERENCES User(userID)" +
                "ON DELETE CASCADE, " +

                "FOREIGN KEY (code) REFERENCES Vaccine(code)" +
                "ON DELETE CASCADE" +
                ")";
        String AllergicTable = "CREATE TABLE AllergicSideEffect(" +
                "effectcode int NOT NULL," +
                "effectname varchar(50)," +
                "PRIMARY KEY (effectcode)" +
                ")";
        String SeenTable = "CREATE TABLE Seen(" +
                "effectcode int," +
                "code int," +
                "userID int," +
                "date date," +
                "degree varchar(30)," +
                "FOREIGN KEY (effectcode) REFERENCES AllergicSideEffect(effectcode)" +
                "ON DELETE SET NULL," +
                "FOREIGN KEY (code) REFERENCES Vaccination(code)" +
                "ON DELETE CASCADE," +
                "FOREIGN KEY (userID) REFERENCES User(userID)" +
                "ON DELETE CASCADE" +
                ")";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(UserTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(VaccineTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        try {
            PreparedStatement preparedStatement = connection.prepareStatement(VaccinationTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(AllergicTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(SeenTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return counter;
    }


    @Override
    public int dropTables() {

        int counter = 0;

        String DropUserTable = "DROP TABLE User";
        String DropVaccineTable = "DROP TABLE Vaccine";
        String DropVaccinationTable = "DROP TABLE Vaccination";
        String DropAllergicSideTable = "DROP TABLE AllergicSideEffect";
        String DropSeenTable = "DROP TABLE Seen";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(DropSeenTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(DropAllergicSideTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(DropVaccinationTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(DropVaccineTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(DropUserTable);
            preparedStatement.executeUpdate();
            counter++;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return counter;
    }

    @Override
    public int insertUser(User[] users) {
        int counter = 0;

        String InsertionToUser = "INSERT INTO User (userID,userName,age,address,password,status) VALUES (?,?,?,?,?,?)";
        for (int i = 0; i < users.length; i++) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(InsertionToUser);
                preparedStatement.setInt(1, users[i].getUserID());
                preparedStatement.setString(2, users[i].getUserName());
                preparedStatement.setInt(3, users[i].getAge());
                preparedStatement.setString(4, users[i].getAddress());
                preparedStatement.setString(5, users[i].getPassword());
                preparedStatement.setString(6, users[i].getStatus());
                preparedStatement.executeUpdate();
                counter++;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return counter;
    }


    @Override
    public int insertVaccine(Vaccine[] vaccines) {
        int counter = 0;
        String InsertionToVaccine = "INSERT INTO Vaccine (code,vaccinename,type) VALUES (?,?,?)";
        for (int i = 0; i < vaccines.length; i++) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(InsertionToVaccine);
                preparedStatement.setInt(1, vaccines[i].getCode());
                preparedStatement.setString(2, vaccines[i].getVaccineName());
                preparedStatement.setString(3, vaccines[i].getType());
                preparedStatement.executeUpdate();
                counter++;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return counter;
    }

    @Override
    public int insertVaccination(Vaccination[] vaccinations) {
        int counter = 0;
        String InsertionToVaccination = "INSERT INTO Vaccination (code,userID,dose,vacdate) VALUES (?,?,?,?)";
        for (int i = 0; i < vaccinations.length; i++) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(InsertionToVaccination);
                preparedStatement.setInt(1, vaccinations[i].getCode());
                preparedStatement.setInt(2, vaccinations[i].getUserID());
                preparedStatement.setInt(3, vaccinations[i].getDose());
                preparedStatement.setString(4, vaccinations[i].getVacdate());
                preparedStatement.executeUpdate();
                counter++;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        }
        return counter;
    }


    @Override
    public int insertAllergicSideEffect(AllergicSideEffect[] sideEffects) {
        int counter = 0;
        String InsertionToAllergic = "INSERT INTO AllergicSideEffect (effectcode,effectname) VALUES (?,?)";
        for (int i = 0; i < sideEffects.length; i++) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(InsertionToAllergic);
                preparedStatement.setInt(1, sideEffects[i].getEffectCode());
                preparedStatement.setString(2, sideEffects[i].getEffectName());

                preparedStatement.executeUpdate();
                counter++;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return counter;
    }


    @Override
    public int insertSeen(Seen[] seens) {
        int counter = 0;
        String InsertionToSeen = "INSERT INTO Seen (effectcode,code,userID,date,degree) VALUES (?,?,?,?,?)";
        for (int i = 0; i < seens.length; i++) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(InsertionToSeen);
                preparedStatement.setInt(1, seens[i].getEffectcode());
                preparedStatement.setInt(2, seens[i].getCode());
                preparedStatement.setString(3, seens[i].getUserID());
                preparedStatement.setString(4, seens[i].getDate());
                preparedStatement.setString(5, seens[i].getDegree());
                preparedStatement.executeUpdate();
                counter++;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return counter;
    }


    @Override
    public Vaccine[] getVaccinesNotAppliedAnyUser() {
        ArrayList<Vaccine> q3OldArr = new ArrayList<Vaccine>();
        String sql = "SELECT DISTINCT V.code,V.vaccinename,V.type" +
                " FROM Vaccine V, Vaccination R" +
                " WHERE V.code NOT IN (SELECT R.code" +
                "                      FROM Vaccine V, Vaccination R" +
                "                      WHERE V.code=R.code)" +
                " ORDER BY V.code ASC";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Vaccine elem = new Vaccine(rs.getInt("code"), rs.getString("vaccinename"), rs.getString("type"));
                q3OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        Vaccine[] q3NewArr = q3OldArr.toArray(new Vaccine[0]);
        return q3NewArr;
    }


    @Override
    public QueryResult.UserIDuserNameAddressResult[] getVaccinatedUsersforTwoDosesByDate(String vacdate) {

        String sql = "SELECT DISTINCT U.userID,U.userName,U.address" +
                " FROM User U,Vaccination R1,Vaccination R2" +
                " WHERE U.userID=R1.userID AND R1.userID=R2.userID   AND R1.dose=1 AND R2.dose=2 AND " +
                " R1.vacdate >= ? AND R2.vacdate >= ? "+
                "AND R2.userID NOT IN( SELECT R1.userID"+
                                    " FROM Vaccination R1"+
                                    " WHERE R1.dose IN(3))"+
                                   " ORDER BY U.userID ASC";


        List<QueryResult.UserIDuserNameAddressResult> q4OldArr = new ArrayList<QueryResult.UserIDuserNameAddressResult>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, vacdate);
            preparedStatement.setString(2, vacdate);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                QueryResult.UserIDuserNameAddressResult elem = new QueryResult.UserIDuserNameAddressResult(rs.getString("userID"), rs.getString("userName"), rs.getString("address"));
                q4OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        QueryResult.UserIDuserNameAddressResult[] q4NewArr = q4OldArr.toArray(new QueryResult.UserIDuserNameAddressResult[0]);
        return q4NewArr;
    }


    @Override
    public Vaccine[] getTwoRecentVaccinesDoNotContainVac() {
        ArrayList<Vaccine> q5OldArr = new ArrayList<Vaccine>();
        String sql = "SELECT DISTINCT V.code,V.vaccinename,V.type" +
                " FROM Vaccine V,  " +
                "  (SELECT R.code , MAX(R.vacdate)" +
                "FROM Vaccination R" +
                " WHERE R.code NOT IN " +
                "( SELECT V.code" +
           " FROM Vaccine V" +
                " WHERE"+
                " V.vaccinename  LIKE '%vac%')" +
                "GROUP BY R.code"+
                " ORDER BY MAX(R.vacdate) DESC"+
            " LIMIT 2) "+
            "AS TUT"+
                " WHERE TUT.code= V.code"+
               " ORDER BY V.code ASC";




        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Vaccine elem = new Vaccine(rs.getInt("code"), rs.getString("vaccinename"), rs.getString("type"));
                q5OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        Vaccine[] q5NewArr = q5OldArr.toArray(new Vaccine[0]);
        return q5NewArr;
    }

    @Override


    public QueryResult.UserIDuserNameAddressResult[] getUsersAtHasLeastTwoDoseAtMostOneSideEffect() {
        String sql = "SELECT DISTINCT U.userID,U.userName,U.address" +
                " FROM User U,Vaccination R1,Vaccination R2"+
                " WHERE R1.userID=R2.userID  AND R1.code=R2.code AND R1.dose<>R2.dose AND R1.userID=U.userID AND "+
                "NOT EXISTS ( SELECT * FROM Seen S1, Seen S2" +
                " WHERE S1.userID=R1.userID AND S2.userID=S1.userID AND S2.code=S1.code AND S1.effectcode<> S2.effectcode) " +
                "ORDER BY U.userID ASC";

        List<QueryResult.UserIDuserNameAddressResult> q6OldArr = new ArrayList<QueryResult.UserIDuserNameAddressResult>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                QueryResult.UserIDuserNameAddressResult elem = new QueryResult.UserIDuserNameAddressResult(rs.getString("userID"), rs.getString("userName"), rs.getString("address"));
                q6OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        QueryResult.UserIDuserNameAddressResult[] q6NewArr = q6OldArr.toArray(new QueryResult.UserIDuserNameAddressResult[0]);
        return q6NewArr;
    }

    @Override
    public QueryResult.UserIDuserNameAddressResult[] getVaccinatedUsersWithAllVaccinesCanCauseGivenSideEffect(String effectname) {

        String sql = "SELECT DISTINCT U.userID,U.userName,U.address" +
                " FROM User U" +
                " WHERE NOT EXISTS(" +
                " SELECT R.userID" +
                " FROM Vaccination R" +
                " WHERE   NOT EXISTS(" +
                " SELECT R.code" +
                " FROM Vaccination R,AllergicSideEffect E,Seen S,Vaccine V" +
                " WHERE U.userID=R.userID" +
                " AND V.code=R.code  AND E.effectname=? AND S.userID=U.userID AND S.effectcode=E.effectcode" +
                ")" +
                ")" +
                " ORDER BY U.userID ASC";

        List<QueryResult.UserIDuserNameAddressResult> q7OldArr = new ArrayList<QueryResult.UserIDuserNameAddressResult>();
        try {

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, effectname);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                QueryResult.UserIDuserNameAddressResult elem = new QueryResult.UserIDuserNameAddressResult(rs.getString("userID"), rs.getString("userName"), rs.getString("address"));
                q7OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        QueryResult.UserIDuserNameAddressResult[] q7NewArr = q7OldArr.toArray(new QueryResult.UserIDuserNameAddressResult[0]);
        return q7NewArr;
    }

    @Override
    public QueryResult.UserIDuserNameAddressResult[] getUsersWithAtLeastTwoDifferentVaccineTypeByGivenInterval(String startdate, String enddate) {
        String sql = "SELECT DISTINCT U.userID,U.userName,U.address" +
                " FROM User U, Vaccination R1,Vaccination R2,Vaccine V1,Vaccine V2" +
                " WHERE U.userID=R1.userID AND U.userID=R2.userID" +
                " AND R1.vacdate>=? AND R1.vacdate<=?" +
                "AND R2.vacdate>=? AND R2.vacdate<=?" +
                "AND R1.code=V1.code AND R2.code=V2.code AND V1.code<>V2.code" +
                " ORDER BY U.userID ASC";

        List<QueryResult.UserIDuserNameAddressResult> q8OldArr = new ArrayList<QueryResult.UserIDuserNameAddressResult>();
        try {

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, startdate);
            preparedStatement.setString(2, enddate);
            preparedStatement.setString(3, startdate);
            preparedStatement.setString(4, enddate);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                QueryResult.UserIDuserNameAddressResult elem = new QueryResult.UserIDuserNameAddressResult(rs.getString("userID"), rs.getString("userName"), rs.getString("address"));
                q8OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        QueryResult.UserIDuserNameAddressResult[] q8NewArr = q8OldArr.toArray(new QueryResult.UserIDuserNameAddressResult[0]);
        return q8NewArr;
    }

    @Override
    public AllergicSideEffect[] getSideEffectsOfUserWhoHaveTwoDosesInLessThanTwentyDays() {
        String sql = "SELECT DISTINCT E.effectcode,E.effectname" +
                " FROM AllergicSideEffect E,Seen S1,Seen S2,Vaccination R1,Vaccination R2" +
                " WHERE S2.userID=S1.userID AND R1.userID=R2.userID AND S1.userID=R1.userID AND S2.userID=R1.userID  AND S1.effectcode=E.effectcode  AND R1.dose=1 AND R2.dose=2 AND R2.vacdate-R1.vacdate<20" +
                 " UNION"+
                " SELECT DISTINCT E.effectcode,E.effectname" +
                " FROM AllergicSideEffect E,Seen S1,Seen S2,Vaccination R1,Vaccination R2" +
                " WHERE S2.userID=S1.userID AND R1.userID=R2.userID AND S1.userID=R1.userID AND S2.userID=R1.userID AND S1.effectcode=E.effectcode  AND R1.dose=2 AND R2.dose=3 AND R2.vacdate-R1.vacdate<20"+
                " UNION"+
                " SELECT DISTINCT E.effectcode,E.effectname" +
                " FROM AllergicSideEffect E,Seen S1,Seen S2,Vaccination R1,Vaccination R2" +
                " WHERE S2.userID=S1.userID AND R1.userID=R2.userID AND S1.userID=R1.userID AND S2.userID=R1.userID  AND S1.effectcode=E.effectcode  AND R1.dose=1 AND R2.dose=3 AND R2.vacdate-R1.vacdate<20"+
                " ORDER BY effectcode ASC";



        List<AllergicSideEffect> q9OldArr = new ArrayList<AllergicSideEffect>();
        try {

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                AllergicSideEffect elem = new AllergicSideEffect(rs.getInt("effectcode"), rs.getString("effectname"));
                q9OldArr.add(elem);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        AllergicSideEffect[] q9NewArr = q9OldArr.toArray(new AllergicSideEffect[0]);
        return q9NewArr;
    }

    @Override
    public double averageNumberofDosesofVaccinatedUserOverSixtyFiveYearsOld() {
        double aver = 0;
        ResultSet r;
        String sql = "SELECT AVG(temp.cnt) FROM " +
                " (SELECT R.userID, COUNT(*) as cnt" +
                " FROM Vaccination R,User U" +
                " WHERE R.userID=U.userID AND U.age>65"+
                " GROUP BY R.userID) as temp ";





        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            r = preparedStatement.executeQuery();
            while (r.next()) {
                aver += r.getDouble(1);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return aver;
    }

    @Override
    public int updateStatusToEligible(String givendate) {
        String sql = "UPDATE User " +
                "set status='Eligible'" +
                " WHERE User.status='Not_Eligible' AND User.userID IN(" +
                "SELECT  R.userID" +
                " FROM Vaccination R " +
                "WHERE DATEDIFF(?,R.vacdate)>=120" +
                "  AND R.vacdate = (SELECT MAX(R.vacdate)"+" FROM Vaccination R" +
                                                              " WHERE User.userID=R.userID)) ";

        int counter = 0;

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, givendate);

            counter = preparedStatement.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return counter;
    }


    @Override
    public Vaccine deleteVaccine(String vaccineName) {


        String sql = "DELETE FROM Vaccine WHERE Vaccine.vaccinename='" + vaccineName+"'";
       String query=" SELECT * FROM Vaccine WHERE vaccinename='" + vaccineName +"' ";
        Vaccine result=null;
        try(Statement stmt = connection.createStatement()) {
           ResultSet rs=stmt.executeQuery(query);
            while (rs.next()) {
                result=new Vaccine(rs.getInt("code"),rs.getString("vaccineName"),rs.getString("type"));
            }


        } catch(SQLException e) {
            e.printStackTrace();
        }
        try(Statement stmt=connection.createStatement()) {
            stmt.executeUpdate(sql);
        }
        catch(SQLException e) {
            e.printStackTrace();
             return null;
        }

        return result;
    }


}